package com.rahmanarifofficial.petraland.view.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.rahmanarifofficial.petraland.R;

public class InputAssetActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_asset);
    }
}
